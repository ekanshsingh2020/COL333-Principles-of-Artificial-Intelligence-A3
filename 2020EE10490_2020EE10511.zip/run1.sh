#!/bin/bash
./part1 $1