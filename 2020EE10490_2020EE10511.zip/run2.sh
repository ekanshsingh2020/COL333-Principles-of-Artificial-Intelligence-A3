#!/bin/bash
./part1_map $1